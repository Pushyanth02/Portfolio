#!/usr/bin/env bash
# package-source.sh — snapshot the project source into public/Portfolio-source.zip
#
# The site is a static export (output: "export") with no server runtime, so
# the only way to offer a downloadable source archive is a static file in
# public/. This script regenerates that snapshot. Run it before deploys so
# the zip always matches the shipped code.
#
# Exclusions keep the archive lean and safe:
#   - build/dev artifacts (node_modules, .next, .git, logs)
#   - platform folders (upload/, tool-results/, skills/) — sandbox tooling,
#     not part of the site source
#   - .env (secrets never ship)
#   - the archive itself (avoids recursive bloat)

set -euo pipefail

PROJECT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$PROJECT/public/Portfolio-source.zip"
TMP="$(mktemp /tmp/portfolio-source-XXXXXX.zip)"

cd "$PROJECT"

rm -f "$OUT" "$TMP"

zip -r -q "$TMP" . \
  -x "node_modules/*" \
     ".next/*" \
     ".git/*" \
     ".turbo/*" \
     "upload/*" \
     "tool-results/*" \
     "agent-ctx/*" \
     "skills/*" \
     "skills-lock.json" \
     "public/Portfolio-source.zip" \
     "dev.log" \
     "*.log" \
     ".env" \
     ".env.*" \
     "*.tsbuildinfo"

mv "$TMP" "$OUT"

echo "✔ wrote $(du -h "$OUT" | cut -f1) → public/Portfolio-source.zip ($(unzip -l "$OUT" | tail -1 | awk '{print $2}') files)"
