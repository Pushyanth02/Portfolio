#!/usr/bin/env bash
# Keepalive watchdog for the portfolio dev server (port 3000).
# Runs forever: polls the server every 15s and restarts it if it dies
# or stops responding. Prevents duplicate instances via a pidfile check.

PROJECT="/home/z/my-project"
PIDFILE="/tmp/portfolio-dev.pid"
LOG="$PROJECT/dev.log"

cd "$PROJECT" || exit 1

while true; do
  # If the server answers, nothing to do.
  if curl -s -o /dev/null --max-time 5 http://localhost:3000/; then
    sleep 15
    continue
  fi

  # Server is down — clean up any zombie processes on port 3000.
  echo "[watchdog $(date '+%F %T')] server unresponsive — restarting" >> "$LOG"
  if [ -f "$PIDFILE" ]; then
    kill "$(cat "$PIDFILE")" 2>/dev/null
    rm -f "$PIDFILE"
  fi
  # Kill anything still holding port 3000.
  fuser -k 3000/tcp 2>/dev/null
  sleep 2

  # Relaunch detached; `bun run dev` tees into dev.log itself.
  nohup bun run dev > /dev/null 2>&1 &
  echo $! > "$PIDFILE"
  # Give it time to boot before the next health check.
  sleep 20
done
