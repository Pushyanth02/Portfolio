// Lightswind UI "Ripple Loader" — concentric ripple rings around a center
// icon (source: Lightswind UI, MIT).
//
// Reworked for this site (transform/opacity-only ripples):
// - backdrop-blur removed (banned here: GPU cost + the Edge PDF-iframe bug).
// - The source animated boxShadow (paint per frame) and ring backgrounds —
//   dropped. Rings animate ONLY scale [1 → 1.28 → 1] and opacity
//   [0.9 → 0.35 → 0.9], staggered; border colors stay static per ring
//   (alpha = 1 - i*0.16, derived from the `color` prop).
// - The icon node is rendered as-is inside a sized wrapper — the source's
//   React.cloneElement games are fragile and gone. The icon itself gets a
//   subtle scale pulse [1 → 1.06 → 1], same duration; no color animation.
// - prefers-reduced-motion: fully static rings (all visible at their fixed
//   alphas) and a static icon.
// - Neutral structure, skinned externally via the `lsw-ripple-*` class hooks.

"use client";

import { useSyncExternalStore, type JSX, type ReactNode } from "react";
import { motion } from "motion/react";

export type RippleLoaderProps = {
  /** Center icon/node. */
  icon?: ReactNode;
  /** Overall size px. */
  size?: number;
  /** Full cycle duration seconds. */
  duration?: number;
  /** Ring base color (any CSS color). */
  color?: string;
  className?: string;
};

const RING_COUNT = 5;
const BASE_INSET_PERCENT = 40;
const INSET_STEP_PERCENT = 10;
const RING_BORDER_PX = 2;
const ICON_PADDING_PERCENT = 22;

/** No-op subscription: the probe is read once, never tracked. */
const subscribeNoop = () => () => {};
/** Server / pre-hydration snapshot: assume motion is allowed. */
const getServerFalse = () => false;

let reducedMotionCache: boolean | null = null;

/** `(prefers-reduced-motion: reduce)` — probed once, then cached. */
const prefersReducedMotion = () =>
  (reducedMotionCache ??= window.matchMedia(
    "(prefers-reduced-motion: reduce)"
  ).matches);

/**
 * Mix any CSS color toward transparent by `alpha` (1 = full color). Hex colors
 * (the default) are parsed directly; everything else (rgb(), named colors,
 * var()…) rides through `color-mix()`.
 */
function colorWithAlpha(color: string, alpha: number): string {
  const trimmed = color.trim();
  const hex = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(trimmed);
  if (hex) {
    const digits =
      hex[1].length === 3
        ? hex[1]
            .split("")
            .map((c) => c + c)
            .join("")
        : hex[1];
    const r = parseInt(digits.slice(0, 2), 16);
    const g = parseInt(digits.slice(2, 4), 16);
    const b = parseInt(digits.slice(4, 6), 16);
    return `rgba(${r}, ${g}, ${b}, ${Number(alpha.toFixed(3))})`;
  }
  return `color-mix(in srgb, ${trimmed} ${Math.round(alpha * 100)}%, transparent)`;
}

/**
 * Loader: five concentric rings scaling/fading around a pulsing center icon.
 * Compositor-friendly — transform and opacity only, no blur, no shadow, no
 * color tweens.
 */
export default function RippleLoader({
  icon,
  size = 160,
  duration = 2,
  color = "#7ee787",
  className,
}: RippleLoaderProps): JSX.Element {
  // useSyncExternalStore keeps this hydration-safe: the server and first
  // client render assume motion, then reduced-motion devices flip to the
  // static rendering right after mount without an effect or mismatch.
  const reducedMotion = useSyncExternalStore(
    subscribeNoop,
    prefersReducedMotion,
    getServerFalse
  );

  const rings = Array.from({ length: RING_COUNT }, (_, i) => ({
    inset: `${BASE_INSET_PERCENT - i * INSET_STEP_PERCENT}%`,
    delay: (i * 0.2 * duration) / 2,
    borderColor: colorWithAlpha(color, 1 - i * 0.16),
    zIndex: RING_COUNT - i,
  }));

  return (
    <div
      className={className ? `lsw-ripple ${className}` : "lsw-ripple"}
      style={{ position: "relative", width: size, height: size }}
    >
      {rings.map((ring, i) => (
        <motion.div
          key={i}
          className="lsw-ripple-ring"
          style={{
            position: "absolute",
            inset: ring.inset,
            zIndex: ring.zIndex,
            borderRadius: "9999px",
            border: `${RING_BORDER_PX}px solid ${ring.borderColor}`,
            pointerEvents: "none",
          }}
          animate={
            reducedMotion
              ? undefined
              : { scale: [1, 1.28, 1], opacity: [0.9, 0.35, 0.9] }
          }
          transition={{
            repeat: Infinity,
            duration,
            delay: ring.delay,
            ease: "easeInOut",
          }}
        />
      ))}

      <div
        style={{
          position: "absolute",
          inset: 0,
          display: "grid",
          placeContent: "center",
          padding: `${ICON_PADDING_PERCENT}%`,
          zIndex: RING_COUNT + 1,
        }}
      >
        <motion.span
          className="lsw-ripple-icon"
          style={{
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            width: "100%",
            height: "100%",
          }}
          animate={
            reducedMotion || !icon ? undefined : { scale: [1, 1.06, 1] }
          }
          transition={{
            repeat: Infinity,
            duration,
            ease: "easeInOut",
          }}
        >
          {icon}
        </motion.span>
      </div>
    </div>
  );
}
