import { assetUrl } from "@/lib/utils";

const LOOK_FOR = [
  "impactful, explainable work",
  "problems worth a whiteboard",
  "talented folks to build with",
];

const FACTS = [
  { k: "based", v: "bangalore, in" },
  { k: "studying", v: "cs @ lpu ’29" },
  { k: "stack", v: "ts · next.js · node" },
  { k: "status", v: "open to collab" },
];

/**
 * About — the opening cover of the notebook. The page now starts with the
 * human: editorial cover grid, polaroid avatar, quick facts strip.
 */
export function About() {
  return (
    <section className="sec about-cover" id="about" aria-label="About Pushyanth">
      <div className="wrap ac-grid">
        <div className="ac-copy">
          <p className="kicker reveal">the human behind the commits</p>
          <h1 className="h2 ac-title">
            <span className="lm">
              <span className="lm-in">What&apos;s his deal?</span>
            </span>
          </h1>
          <p className="reveal" style={{ "--d": ".1s" } as React.CSSProperties}>
            I&apos;m Pushyanth, a computer science student and software crafter.
            I build with AI and keep every system explainable. Days go to
            data structures and algorithms; evenings go to full-stack builds
            with Claude, Codex and friends in the loop. Whatever catches my
            curiosity, AI/ML or cloud, I study it hands-first and explain it
            always.
          </p>
          <p className="reveal" style={{ "--d": ".18s" } as React.CSSProperties}>
            When I&apos;m not shipping, I wander open-source repos, chase new AI
            tooling, and carry the interesting bits back into my own projects.
          </p>
          <ul
            className="lookfor reveal"
            style={{ "--d": ".26s" } as React.CSSProperties}
          >
            {LOOK_FOR.map((t) => (
              <li key={t}>
                <span className="tick">
                  {/* inline check — single-use, avoids an import */}
                  <svg className="ic" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="m20 6-11 11-5-5" />
                  </svg>
                </span>
                {t}
              </li>
            ))}
          </ul>
          <dl
            className="ac-facts reveal"
            style={{ "--d": ".34s" } as React.CSSProperties}
          >
            {FACTS.map((f) => (
              <div className="ac-fact" key={f.k}>
                <dt>{f.k}</dt>
                <dd>{f.v}</dd>
              </div>
            ))}
          </dl>
        </div>
        <figure
          className="ac-fig reveal"
          style={{ "--d": ".15s" } as React.CSSProperties}
        >
          <div className="ac-polaroid">
            <img
              src={assetUrl("/art/doodle.webp")}
              alt="Illustrated doodle avatar: an infinity symbol with eyes, a graduation cap and a laptop"
              width={720}
              height={720}
              loading="eager"
              decoding="async"
              fetchPriority="high"
              sizes="(max-width: 960px) min(440px, 100vw), 33vw"
            />
          </div>
          <figcaption>the resident infinity · drawn in-house</figcaption>
        </figure>
      </div>
    </section>
  );
}
